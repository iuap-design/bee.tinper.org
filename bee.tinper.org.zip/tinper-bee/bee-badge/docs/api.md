## Badge

用来醒目的展示新的或未读的信息条目


### API

|参数|说明|类型|默认值|
|:--|:---|:--|:---|
|colors|one of: `primary` `success` `info` `error`  `warning` `dark`|string|''|
|dataBadge|图标右上角的数字|obj/string/node|-|
|dataBadgePlacement|数字显示位置 oneOf:top,bottom|string|top|
|className|增加额外的class|string|''|



