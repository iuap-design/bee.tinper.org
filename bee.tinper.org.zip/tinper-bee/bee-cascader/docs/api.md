## Cascader 级联菜单

级联选择框。

## 代码演示

### API

|参数|说明|类型|默认值|
|:---|:----|:---|:------|
|placeholder	|input提示信息|	string	|"请输入信息"|
|options	|下拉列表数据	|json|	必填，无默认值|
