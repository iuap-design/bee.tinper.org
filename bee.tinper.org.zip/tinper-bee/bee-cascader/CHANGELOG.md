<a name="1.0.4"></a>
## 1.0.4 (2018-07-03)


### Bug Fixes

* demo展示bug ([5d17320](https://github.com/tinper-bee/bee-cascader/commit/5d17320))
* 修改示例 ([1b72758](https://github.com/tinper-bee/bee-cascader/commit/1b72758))
* **add onclick function:** add onclick function ([84209ee](https://github.com/tinper-bee/bee-cascader/commit/84209ee))


### build

* **工具编译:** 工具编译 ([3752fb8](https://github.com/tinper-bee/bee-cascader/commit/3752fb8))


### Documentation

* **bee-tools cmd:** bee-tools cmd ([fcfd2e7](https://github.com/tinper-bee/bee-cascader/commit/fcfd2e7))


### Tests

* **工具升级:** 工具升级 ([c37b6b9](https://github.com/tinper-bee/bee-cascader/commit/c37b6b9))


### BREAKING CHANGES

* **工具编译:** 工具编译
* **工具升级:** 工具升级
* **bee-tools cmd:** bee-tools cmd



