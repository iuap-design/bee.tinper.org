<a name="1.0.1"></a>
## 1.0.1 (2018-01-20)


### Bug Fixes

* **bee-dropdown:** fix:修复父组件重新渲染，下拉菜单没有销毁的bug ([e47c135](https://github.com/tinper-bee/bee-dropdown/commit/e47c135))
* demo展示bug ([08d80ab](https://github.com/tinper-bee/bee-dropdown/commit/08d80ab))
* 修复demo ([3cafad7](https://github.com/tinper-bee/bee-dropdown/commit/3cafad7))


### build

* **组件依赖清理,changelog:** 组件依赖清理,changelog ([2412f07](https://github.com/tinper-bee/bee-dropdown/commit/2412f07))


### BREAKING CHANGES

* **组件依赖清理,changelog:** 组件依赖清理,changelog



