<a name="1.0.4"></a>
## [1.0.4](https://github.com/tinper-bee/bee-affix/compare/v1.0.3...v1.0.4) (2018-08-14)



<a name="1.0.3"></a>
## 1.0.3 (2018-08-10)



