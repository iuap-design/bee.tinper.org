import React from 'react';
import {shallow, mount, render} from 'enzyme';
import {expect} from 'chai';
import Affix from '../src/index';