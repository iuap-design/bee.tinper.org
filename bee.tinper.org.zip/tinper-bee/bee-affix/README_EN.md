# bee-affix

[![npm version](https://img.shields.io/npm/v/bee-affix.svg)](https://www.npmjs.com/package/bee-affix)
[![Build Status](https://img.shields.io/travis/tinper-bee/bee-affix/master.svg)](https://travis-ci.org/tinper-bee/bee-affix)
[![Coverage Status](https://coveralls.io/repos/github/tinper-bee/bee-affix/badge.svg?branch=master)](https://coveralls.io/github/tinper-bee/bee-affix?branch=master)
[![devDependency Status](https://img.shields.io/david/dev/tinper-bee/bee-affix.svg)](https://david-dm.org/tinper-bee/bee-affix#info=devDependencies)
[![NPM downloads](http://img.shields.io/npm/dm/bee-affix.svg?style=flat)](https://npmjs.org/package/bee-affix)
[![Average time to resolve an issue](http://isitmaintained.com/badge/resolution/tinper-bee/bee-affix.svg)](http://isitmaintained.com/project/tinper-bee/bee-affix "Average time to resolve an issue")
[![Percentage of issues still open](http://isitmaintained.com/badge/open/tinper-bee/bee-affix.svg)](http://isitmaintained.com/project/tinper-bee/bee-affix "Percentage of issues still open")



react bee-affix component for tinper-bee


## Usage

```js


```



## API

|参数|说明|类型|默认值|
|:--|:---:|:--:|---:|

#### develop

```sh
$ npm install -g bee-tools
$ git clone https://github.com/tinper-bee/bee-affix
$ cd bee-affix
$ npm install
$ npm run dev
```
