<a name="1.0.4"></a>
## 1.0.4 (2018-01-11)


### Bug Fixes

* no build fix it ([f54e076](https://github.com/tinper-bee/icon/commit/f54e076))


### build

* **组件清理:** 组件清理 ([e7f2623](https://github.com/tinper-bee/icon/commit/e7f2623))


### Features

* **bee-icon:** 增加样式 ([9caf880](https://github.com/tinper-bee/icon/commit/9caf880))


### BREAKING CHANGES

* **组件清理:** 组件清理



