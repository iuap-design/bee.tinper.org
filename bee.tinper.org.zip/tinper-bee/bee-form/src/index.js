import Form from './Form';
import FormItem from './FormItem';
Form.FormItem=FormItem;
export default Form;