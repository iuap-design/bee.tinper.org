<a name="1.1.0"></a>
# 1.1.0 (2018-01-21)


### Bug Fixes

* 去掉rem ([7b9ed74](https://github.com/tinper-bee/bee-button-group/commit/7b9ed74))


### Features

* **bee-button-group:** 新增list接口，可传入数据和props，来渲染button，并且提供选中样式 ([4342db5](https://github.com/tinper-bee/bee-button-group/commit/4342db5))



