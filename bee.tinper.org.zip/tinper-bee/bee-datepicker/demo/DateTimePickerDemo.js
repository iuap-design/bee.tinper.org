import DatePicker from '../src/index';
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
class Demo extends Component {render(){return( <DatePicker/> )}}
export default Demo;