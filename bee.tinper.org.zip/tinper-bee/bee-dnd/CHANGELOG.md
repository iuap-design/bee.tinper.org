<a name="1.0.2"></a>
## [1.0.2](https://github.com/tinper-bee/bee-dnd/compare/v1.0.1...v1.0.2) (2018-05-02)


### Bug Fixes

* 修改示例 ([ee2193c](https://github.com/tinper-bee/bee-dnd/commit/ee2193c))



<a name="1.0.1"></a>
## [1.0.1](https://github.com/tinper-bee/bee-dnd/compare/754e50c...v1.0.1) (2018-01-16)


### Features

* **demo.js:** 修改示例代码展现方式 ([754e50c](https://github.com/tinper-bee/bee-dnd/commit/754e50c))



