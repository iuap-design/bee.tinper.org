# bee-dnd

[![npm version](https://img.shields.io/npm/v/bee-dnd.svg)](https://www.npmjs.com/package/bee-dnd)
[![Build Status](https://img.shields.io/travis/tinper-bee/bee-dnd/master.svg)](https://travis-ci.org/tinper-bee/bee-dnd)
[![Coverage Status](https://coveralls.io/repos/github/tinper-bee/bee-dnd/badge.svg?branch=master)](https://coveralls.io/github/tinper-bee/bee-dnd?branch=master)
[![devDependency Status](https://img.shields.io/david/dev/tinper-bee/bee-dnd.svg)](https://david-dm.org/tinper-bee/bee-dnd#info=devDependencies)
[![NPM downloads](http://img.shields.io/npm/dm/bee-dnd.svg?style=flat)](https://npmjs.org/package/bee-dnd)
[![Average time to resolve an issue](http://isitmaintained.com/badge/resolution/tinper-bee/bee-dnd.svg)](http://isitmaintained.com/project/tinper-bee/bee-dnd "Average time to resolve an issue")
[![Percentage of issues still open](http://isitmaintained.com/badge/open/tinper-bee/bee-dnd.svg)](http://isitmaintained.com/project/tinper-bee/bee-dnd "Percentage of issues still open")



react bee-dnd component for tinper-bee


## Usage

```js


```



## API

|参数|说明|类型|默认值|
|:--|:---:|:--:|---:|

#### develop

```sh
$ npm install -g bee-tools
$ git clone https://github.com/tinper-bee/bee-dnd
$ cd bee-dnd
$ npm install
$ npm run dev
```
