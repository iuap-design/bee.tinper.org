import Dnd from '../src/index';
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
class Demo extends Component {render(){return( <Dnd/> )}}
export default Demo;