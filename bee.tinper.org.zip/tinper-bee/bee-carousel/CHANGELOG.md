<a name="1.0.0"></a>
# 1.0.0 (2018-01-22)


### Features

* **bee-carousel:** 发布轮播图组件 bee-carousel ([36cd0fd](https://github.com/tinper-bee/bee-carousel/commit/36cd0fd))
* **bee-swiper 发布:** 发布轮播图组件 ([5e48f15](https://github.com/tinper-bee/bee-carousel/commit/5e48f15))



