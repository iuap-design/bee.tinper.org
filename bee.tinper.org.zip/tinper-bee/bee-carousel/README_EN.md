# bee-carousel

[![npm version](https://img.shields.io/npm/v/bee-carousel.svg)](https://www.npmjs.com/package/bee-carousel)
[![Build Status](https://img.shields.io/travis/tinper-bee/bee-carousel/master.svg)](https://travis-ci.org/tinper-bee/bee-carousel)
[![Coverage Status](https://coveralls.io/repos/github/tinper-bee/bee-carousel/badge.svg?branch=master)](https://coveralls.io/github/tinper-bee/bee-carousel?branch=master)
[![devDependency Status](https://img.shields.io/david/dev/tinper-bee/bee-carousel.svg)](https://david-dm.org/tinper-bee/bee-carousel#info=devDependencies)
[![NPM downloads](http://img.shields.io/npm/dm/bee-carousel.svg?style=flat)](https://npmjs.org/package/bee-carousel)
[![Average time to resolve an issue](http://isitmaintained.com/badge/resolution/tinper-bee/bee-carousel.svg)](http://isitmaintained.com/project/tinper-bee/bee-carousel "Average time to resolve an issue")
[![Percentage of issues still open](http://isitmaintained.com/badge/open/tinper-bee/bee-carousel.svg)](http://isitmaintained.com/project/tinper-bee/bee-carousel "Percentage of issues still open")



react bee-carousel component for tinper-bee

## Rely

- react >= 15.3.0
- react-dom >= 15.3.0
- prop-types >= 15.6.0

## Usage

```js


```



## API

|参数|说明|类型|默认值|
|:--|:---:|:--:|---:|

#### develop

```sh
$ npm install -g bee-tools
$ git clone https://github.com/tinper-bee/bee-carousel
$ cd bee-carousel
$ npm install
$ npm run dev
```
