<a name="1.1.0"></a>
# [1.1.0](https://github.com/tinper-bee/checkbox/compare/v1.0.10...v1.1.0) (2018-06-27)


### Features

* bee-checkbox ([f89624e](https://github.com/tinper-bee/checkbox/commit/f89624e))



<a name="1.0.9"></a>
## [1.0.9](https://github.com/tinper-bee/checkbox/compare/v1.0.8...v1.0.9) (2018-05-10)


### Bug Fixes

* bee-checkbox ([e776b8a](https://github.com/tinper-bee/checkbox/commit/e776b8a))



<a name="1.0.8"></a>
## [1.0.8](https://github.com/tinper-bee/checkbox/compare/v1.0.7...v1.0.8) (2018-04-11)



<a name="1.0.7"></a>
## [1.0.7](https://github.com/tinper-bee/checkbox/compare/v1.0.6...v1.0.7) (2018-04-10)



<a name="1.0.6"></a>
## [1.0.6](https://github.com/tinper-bee/checkbox/compare/v1.0.5...v1.0.6) (2018-04-08)



<a name="1.0.5"></a>
## [1.0.5](https://github.com/tinper-bee/checkbox/compare/v1.0.3...v1.0.5) (2018-01-21)



<a name="1.0.3"></a>
## [1.0.3](https://github.com/tinper-bee/checkbox/compare/4af7c2e...v1.0.3) (2018-01-16)


### Bug Fixes

* demo展示bug ([4af7c2e](https://github.com/tinper-bee/checkbox/commit/4af7c2e))


### Features

* **checkbox.scss:** 新增checkbox在disabled状态时的鼠标样式 ([89f8403](https://github.com/tinper-bee/checkbox/commit/89f8403))
* **demo.js:** 修改demo展现方式 ([8630a32](https://github.com/tinper-bee/checkbox/commit/8630a32))



