<a name="1.0.6"></a>
## 1.0.6 (2018-01-21)


### Bug Fixes

* demo 显示bug ([2ce351b](https://github.com/tinper-bee/button/commit/2ce351b))


### Features

* **bee-button:** 增加 isSubmit props ([a808ca1](https://github.com/tinper-bee/button/commit/a808ca1))



