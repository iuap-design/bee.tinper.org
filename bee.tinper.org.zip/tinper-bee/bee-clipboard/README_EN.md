# bee-clipboard

[![npm version](https://img.shields.io/npm/v/bee-clipboard.svg)](https://www.npmjs.com/package/bee-clipboard)
[![Build Status](https://img.shields.io/travis/tinper-bee/bee-clipboard/master.svg)](https://travis-ci.org/tinper-bee/bee-clipboard)
[![Coverage Status](https://coveralls.io/repos/github/tinper-bee/bee-clipboard/badge.svg?branch=master)](https://coveralls.io/github/tinper-bee/bee-clipboard?branch=master)
[![devDependency Status](https://img.shields.io/david/dev/tinper-bee/bee-clipboard.svg)](https://david-dm.org/tinper-bee/bee-clipboard#info=devDependencies)
[![NPM downloads](http://img.shields.io/npm/dm/bee-clipboard.svg?style=flat)](https://npmjs.org/package/bee-clipboard)
[![Average time to resolve an issue](http://isitmaintained.com/badge/resolution/tinper-bee/bee-clipboard.svg)](http://isitmaintained.com/project/tinper-bee/bee-clipboard "Average time to resolve an issue")
[![Percentage of issues still open](http://isitmaintained.com/badge/open/tinper-bee/bee-clipboard.svg)](http://isitmaintained.com/project/tinper-bee/bee-clipboard "Percentage of issues still open")



react bee-clipboard component for tinper-bee


## Usage

```js


```



## API

|参数|说明|类型|默认值|
|:--|:---:|:--:|---:|

#### develop

```sh
$ npm install -g bee-tools
$ git clone https://github.com/tinper-bee/bee-clipboard
$ cd bee-clipboard
$ npm install
$ npm run dev
```
