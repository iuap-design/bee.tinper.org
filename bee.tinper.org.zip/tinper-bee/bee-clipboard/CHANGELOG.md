<a name="1.0.4"></a>
## 1.0.4 (2018-01-16)


### Bug Fixes

* **bee-clipboard:** 多语配置修改 ([283d952](https://github.com/tinper-bee/bee-clipboard/commit/283d952))


### Features

* **demo.js:** 修改demo展现方式 ([40c545c](https://github.com/tinper-bee/bee-clipboard/commit/40c545c))



