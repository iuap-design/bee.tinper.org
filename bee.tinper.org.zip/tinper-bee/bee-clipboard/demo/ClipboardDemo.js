import Clipboard from '../src/index';
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
class Demo extends Component {
    render() {
        return ( <Clipboard/> )
    }
}
export default Demo;