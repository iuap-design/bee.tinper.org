import Clipboard from './Clipboard';
export default Clipboard;