export default {
    lang: 'en_US',
    copy: 'copy',
    cut: 'cut',
    copyReady: 'copied',
    cutReady: 'cut',
    copyToClipboard:'copy to clipboard',
    close:'close'
}