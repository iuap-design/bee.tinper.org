import AutoComplete from '../src/index';
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
class Demo extends Component {render(){return( <AutoComplete/> )}}
export default Demo;