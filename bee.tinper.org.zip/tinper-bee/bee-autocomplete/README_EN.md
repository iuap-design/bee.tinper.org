# bee-auto-complete

[![npm version](https://img.shields.io/npm/v/bee-auto-complete.svg)](https://www.npmjs.com/package/bee-auto-complete)
[![Build Status](https://img.shields.io/travis/tinper-bee/bee-auto-complete/master.svg)](https://travis-ci.org/tinper-bee/bee-auto-complete)
[![Coverage Status](https://coveralls.io/repos/github/tinper-bee/bee-auto-complete/badge.svg?branch=master)](https://coveralls.io/github/tinper-bee/bee-auto-complete?branch=master)
[![devDependency Status](https://img.shields.io/david/dev/tinper-bee/bee-auto-complete.svg)](https://david-dm.org/tinper-bee/bee-auto-complete#info=devDependencies)
[![NPM downloads](http://img.shields.io/npm/dm/bee-auto-complete.svg?style=flat)](https://npmjs.org/package/bee-auto-complete)
[![Average time to resolve an issue](http://isitmaintained.com/badge/resolution/tinper-bee/bee-auto-complete.svg)](http://isitmaintained.com/project/tinper-bee/bee-auto-complete "Average time to resolve an issue")
[![Percentage of issues still open](http://isitmaintained.com/badge/open/tinper-bee/bee-auto-complete.svg)](http://isitmaintained.com/project/tinper-bee/bee-auto-complete "Percentage of issues still open")



react bee-auto-complete component for tinper-bee


## Usage

```js


```



## API

|参数|说明|类型|默认值|
|:--|:---:|:--:|---:|

#### develop

```sh
$ npm install -g bee-tools
$ git clone https://github.com/tinper-bee/bee-auto-complete
$ cd bee-auto-complete
$ npm install
$ npm run dev
```
