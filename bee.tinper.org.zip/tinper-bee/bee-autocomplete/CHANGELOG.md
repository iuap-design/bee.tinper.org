<a name="1.0.4"></a>
## 1.0.4 (2018-03-08)


### Bug Fixes

* 修改样式规范，修改依赖引入 ([70333a7](https://github.com/tinper-bee/bee-auto-complete/commit/70333a7))
* 修改示例 ([eb6ba30](https://github.com/tinper-bee/bee-auto-complete/commit/eb6ba30))


### Features

* **AutoComplete.js:** 支持options参数动态变更 ([4cec152](https://github.com/tinper-bee/bee-auto-complete/commit/4cec152))



