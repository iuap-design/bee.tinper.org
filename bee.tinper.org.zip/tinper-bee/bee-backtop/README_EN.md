# bee-backtop

[![npm version](https://img.shields.io/npm/v/bee-backtop.svg)](https://www.npmjs.com/package/bee-backtop)
[![Build Status](https://img.shields.io/travis/tinper-bee/bee-backtop/master.svg)](https://travis-ci.org/tinper-bee/bee-backtop)
[![Coverage Status](https://coveralls.io/repos/github/tinper-bee/bee-backtop/badge.svg?branch=master)](https://coveralls.io/github/tinper-bee/bee-backtop?branch=master)
[![devDependency Status](https://img.shields.io/david/dev/tinper-bee/bee-backtop.svg)](https://david-dm.org/tinper-bee/bee-backtop#info=devDependencies)
[![NPM downloads](http://img.shields.io/npm/dm/bee-backtop.svg?style=flat)](https://npmjs.org/package/bee-backtop)
[![Average time to resolve an issue](http://isitmaintained.com/badge/resolution/tinper-bee/bee-backtop.svg)](http://isitmaintained.com/project/tinper-bee/bee-backtop "Average time to resolve an issue")
[![Percentage of issues still open](http://isitmaintained.com/badge/open/tinper-bee/bee-backtop.svg)](http://isitmaintained.com/project/tinper-bee/bee-backtop "Percentage of issues still open")



react bee-backtop component for tinper-bee


## Usage

```js


```



## API

|参数|说明|类型|默认值|
|:--|:---:|:--:|---:|

#### develop

```sh
$ npm install -g bee-tools
$ git clone https://github.com/tinper-bee/bee-backtop
$ cd bee-backtop
$ npm install
$ npm run dev
```
