import Backtop from '../src/index';
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
class Demo extends Component {render(){return( <Backtop/> )}}
export default Demo;