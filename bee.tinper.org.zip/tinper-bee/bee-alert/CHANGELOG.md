<a name="1.0.2"></a>
## 1.0.2 (2018-01-21)


### Bug Fixes

* **bee-alert:** fix warning ([b1e6886](https://github.com/tinper-bee/alert/commit/b1e6886))
* **props closeLabel:** 修改关闭按钮的样式 ([6d87ad1](https://github.com/tinper-bee/alert/commit/6d87ad1))
* demno显示bug ([8bd2e4e](https://github.com/tinper-bee/alert/commit/8bd2e4e))



