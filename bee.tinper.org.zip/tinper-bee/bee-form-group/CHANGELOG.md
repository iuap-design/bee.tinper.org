<a name="1.0.13"></a>
## 1.0.13 (2018-01-16)


### Bug Fixes

* **bee-form-control:** change dependencies ([c20d97a](https://github.com/tinper-bee/bee-form-group/commit/c20d97a))



