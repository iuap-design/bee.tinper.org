## FormGroup

`FormGroup` 组件用来包裹像 `form control` `lable` `help text` `validate state`的元素

## 代码演示

### API

|参数|说明|类型|默认值|
|:--|:---|:--|---|
|className|类名|string|-|
|validationState|oneOf:`success` `error` `warning`|string|''|



