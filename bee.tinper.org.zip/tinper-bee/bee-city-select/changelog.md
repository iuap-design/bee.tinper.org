<a name="1.0.6"></a>
## [1.0.6](https://github.com/tinper-bee/bee-city-select/compare/v1.0.4...v1.0.6) (2018-03-02)



<a name="1.0.4"></a>
## 1.0.4 (2018-03-01)



