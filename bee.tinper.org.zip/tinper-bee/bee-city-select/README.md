# bee-city-select

[![npm version](https://img.shields.io/npm/v/bee-city-select.svg)](https://www.npmjs.com/package/bee-city-select)
[![Build Status](https://img.shields.io/travis/tinper-bee/bee-city-select/master.svg)](https://travis-ci.org/tinper-bee/bee-city-select)
[![Coverage Status](https://coveralls.io/repos/github/tinper-bee/bee-city-select/badge.svg?branch=master)](https://coveralls.io/github/tinper-bee/bee-city-select?branch=master)
[![devDependency Status](https://img.shields.io/david/dev/tinper-bee/bee-city-select.svg)](https://david-dm.org/tinper-bee/bee-city-select#info=devDependencies)
[![NPM downloads](http://img.shields.io/npm/dm/bee-city-select.svg?style=flat)](https://npmjs.org/package/bee-city-select)
[![Average time to resolve an issue](http://isitmaintained.com/badge/resolution/tinper-bee/bee-city-select.svg)](http://isitmaintained.com/project/tinper-bee/bee-city-select "Average time to resolve an issue")
[![Percentage of issues still open](http://isitmaintained.com/badge/open/tinper-bee/bee-city-select.svg)](http://isitmaintained.com/project/tinper-bee/bee-city-select "Percentage of issues still open")


react bee-city-select component for tinper-bee

地区级联

## 使用方法

```js

import ReactDom from 'react-dom';
import CitySelect from 'bee-city-select';

ReactDom.render(<CitySelect />,document.getElementById('app'));

```



## API

|参数|说明|类型|默认值|
|:---|:-----|:----|:------|
|className|类名|string|-|
|defaultValue|默认值,格式为`{ province:'北京',city:'北京',area:'东城区'}`|array|{ province:'北京',city:'北京',area:'东城区'}|
|onChange|改变时的回调，参数为当前值，格式为`{ province:'北京',city:'北京',area:'东城区'}`|function|-|

#### 开发调试

```sh
$ npm install -g bee-tools
$ git clone https://github.com/tinper-bee/bee-city-select
$ cd bee-city-select
$ npm install
$ npm run dev
```
