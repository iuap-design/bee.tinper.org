# CitySelect

地区级联

## 代码演示

## API
|参数|说明|类型|默认值|
|:---|:-----|:----|:------|
|className|类名|string|-|
|defaultValue|默认值,格式为`{ province:'北京',city:'北京',area:'东城区'}`|array|{ province:'北京',city:'北京',area:'东城区'}|
|onChange|改变时的回调，参数为当前值，格式为`{ province:'北京',city:'北京',area:'东城区'}`|function|-|
