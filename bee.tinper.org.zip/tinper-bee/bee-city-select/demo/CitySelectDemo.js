import CitySelect from '../src/index';
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
class Demo extends Component {render(){return( <CitySelect/> )}}
export default Demo;