# bee-calendar

[![npm version](https://img.shields.io/npm/v/bee-calendar.svg)](https://www.npmjs.com/package/bee-calendar)
[![Build Status](https://img.shields.io/travis/tinper-bee/bee-calendar/master.svg)](https://travis-ci.org/tinper-bee/bee-calendar)
[![Coverage Status](https://coveralls.io/repos/github/tinper-bee/bee-calendar/badge.svg?branch=master)](https://coveralls.io/github/tinper-bee/bee-calendar?branch=master)
[![devDependency Status](https://img.shields.io/david/dev/tinper-bee/bee-calendar.svg)](https://david-dm.org/tinper-bee/bee-calendar#info=devDependencies)
[![NPM downloads](http://img.shields.io/npm/dm/bee-calendar.svg?style=flat)](https://npmjs.org/package/bee-calendar)
[![Average time to resolve an issue](http://isitmaintained.com/badge/resolution/tinper-bee/bee-calendar.svg)](http://isitmaintained.com/project/tinper-bee/bee-calendar "Average time to resolve an issue")
[![Percentage of issues still open](http://isitmaintained.com/badge/open/tinper-bee/bee-calendar.svg)](http://isitmaintained.com/project/tinper-bee/bee-calendar "Percentage of issues still open")



react bee-calendar component for tinper-bee


## Usage

```js


```



## API

|参数|说明|类型|默认值|
|:--|:---:|:--:|---:|

#### develop

```sh
$ npm install -g bee-tools
$ git clone https://github.com/tinper-bee/bee-calendar
$ cd bee-calendar
$ npm install
$ npm run dev
```
