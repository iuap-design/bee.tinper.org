<a name="1.0.1"></a>
## 1.0.1 (2017-11-02)


### build

* **组价依赖清理、changelog:** 组价依赖清理、changelog ([0bfecf7](https://github.com/tinper-bee/bee-collapse/commit/0bfecf7))


### BREAKING CHANGES

* **组价依赖清理、changelog:** 组价依赖清理、changelog



