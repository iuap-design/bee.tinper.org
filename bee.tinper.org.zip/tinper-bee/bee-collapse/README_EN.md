# bee-collapse

[![npm version](https://img.shields.io/npm/v/bee-collapse.svg)](https://www.npmjs.com/package/bee-collapse)
[![Build Status](https://img.shields.io/travis/tinper-bee/bee-collapse/master.svg)](https://travis-ci.org/tinper-bee/bee-collapse)
[![Coverage Status](https://coveralls.io/repos/github/tinper-bee/bee-collapse/badge.svg?branch=master)](https://coveralls.io/github/tinper-bee/bee-collapse?branch=master)
[![devDependency Status](https://img.shields.io/david/dev/tinper-bee/bee-collapse.svg)](https://david-dm.org/tinper-bee/bee-collapse#info=devDependencies)
[![NPM downloads](http://img.shields.io/npm/dm/bee-collapse.svg?style=flat)](https://npmjs.org/package/bee-collapse)
[![Average time to resolve an issue](http://isitmaintained.com/badge/resolution/tinper-bee/bee-collapse.svg)](http://isitmaintained.com/project/tinper-bee/bee-collapse "Average time to resolve an issue")
[![Percentage of issues still open](http://isitmaintained.com/badge/open/tinper-bee/bee-collapse.svg)](http://isitmaintained.com/project/tinper-bee/bee-collapse "Percentage of issues still open")



react bee-collapse component for tinper-bee


## Usage

```js


```



## API

|参数|说明|类型|默认值|
|:--|:---:|:--:|---:|

#### develop

```sh
$ npm install -g bee-tools
$ git clone https://github.com/tinper-bee/bee-collapse
$ cd bee-collapse
$ npm install
$ npm run dev
```
