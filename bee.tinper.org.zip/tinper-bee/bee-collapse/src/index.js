import Collapse from './Collapse';
export default Collapse;